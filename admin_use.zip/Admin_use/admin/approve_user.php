<?php  include('../config.php'); ?>
<?php  include(ROOT_PATH . '/admin/includes/admin_functions.php'); ?>
<?php 
	// Get all admin users from DB
	$not_approved_users = getNewUsers();	
	//$roles = ['Admin ', 'Author'];				
?>
<?php include(ROOT_PATH . '/admin/includes/head_section.php'); ?>
	<title>Admin | Approve New users</title>
</head>
<body>
	<!-- admin navbar -->
	<?php include(ROOT_PATH . '/admin/includes/navbar.php') ?>
	<div class="container content">
		<!-- Left side menu -->
		<?php include(ROOT_PATH . '/admin/includes/menu.php') ?>
		<!-- Middle form - to create and edit  -->

		<center>
		<div class="">
			<h1 class="page-title">Approve/Disapprove New User</h1>
		<!-- // Middle form - to create and edit -->

		<!-- Display records from DB-->
		<div class="table-div">
			<!-- Display notification message -->
			<?php include(ROOT_PATH . '/includes/messages.php') ?>

			<?php if (empty($not_approved_users)): ?>
				<h1>No New Arrived users.</h1>
			<?php else: ?>
				<table class="table" align="center">
					<thead>
						<th colspan="6">Newly Arrived Users list</th>
					</thead>
					<thead>
						<th>ID</th>
						<th>UserName</th>
						<th>Role</th>
						<th>Profile Status</th>
						<th colspan="2">Action</th>
					</thead>
					<tbody>
					<?php foreach ($not_approved_users as $key => $user): ?>
						<tr>
							<td><?php echo $key + 1; ?></td>
							<td>
								<?php echo $user['username']; ?>, &nbsp;
								<?php echo  $user['email']; ?>	
							</td>
							<td><?php

							if ($user['Role']=="1")
						    {
							 echo "Farmer";
							} 
							else  {
								echo "Broker";
							}

							?></td>
							<td>
								<?php echo  $user['profile_status']; ?>
							</td>
							<td>
								<a class="fa fa-pencil btn edit"
									href="approve_user.php?approved-user=<?php echo $user['id'] ?>">
								</a>
							</td>
							<td>
								<a class="fa fa-trash btn delete" 
								    href="approve_user.php?delete-user=<?php echo $user['id'] ?>">
								</a>
							</td>
						</tr>
					<?php endforeach ?>
					</tbody>
				</table>
			<?php endif ?>
		</div>
		<!-- // Display records from DB -->
		</div>
	</center>
	</div>
</body>
</html>
