<div class="footer">
			<p>MyViewers &copy; <?php echo date('Y'); ?></p>
		</div>
	</div>
	<!-- // container -->
</body>
</html>